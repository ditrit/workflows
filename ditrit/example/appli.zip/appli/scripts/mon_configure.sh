#!/bin/bash

echo Mon configure.sh s'execute !!!

